var VKcnt=0;
var VK = {};
VK.Share = {};
VK.Share.count = function(index, count) {
	//console.log(count);
	//alert(count);
	VKcnt=count;
}
var OKcnt=0;
var ODKL={};
ODKL.updateCount = function(i,count){
	//console.log(count);
	//alert(count);
	OKcnt=count;
}
function CntView(sw,cntjs){
	cnt=Object.keys(cntjs);
	cnt.forEach(function(entry){
		if(document.body.clientWidth<sw)entry='';
		switch(entry) {
		case 'fb':
			jQuery.ajax({
				url:'https://graph.facebook.com/?id='+encodeURIComponent(location.href)+'&fields=og_object{engagement}',
				type:'POST',
				dataType: "jsonp",
				crossDomain: true,
	            accept: 'application/json',
				complete: function(data){
					if(data.success){
						dt=data;
						s=dt.responseJSON;
						if((typeof s.og_object.engagement.count) != "undefined"){
							if(s.og_object.engagement.count>0)jQuery('i.ico-fb').text(s.og_object.engagement.count);
						}
					}
		     	}
			});
			break;
		case 'vk':
			jQuery.ajax({
				url:'https://vk.com/share.php?act=count&index=0&url='+encodeURIComponent(location.href),
				type:'POST',
				dataType: "jsonp",
				crossDomain: true,
	            accept: 'application/json',
				complete: function(data){
					if(data.success){
						if(VKcnt>0)jQuery('i.ico-vk').text(VKcnt);
					}
		     	}
			});
			break;
		case 'ok':
			jQuery.ajax({
				url:'https://connect.ok.ru/dk?st.cmd=extLike&ref='+encodeURIComponent(location.href),
				type:'POST',
				dataType: "jsonp",
				crossDomain: true,
	            accept: 'application/json',
				complete: function(data){
					if(data.success){
						//alert(OKcnt);
						if(OKcnt>0)jQuery('i.ico-ok').text(OKcnt);
					}
		     	}
			});
			break;
		default:
		}
	});
}
function get_og_param(name) {
    return jQuery('meta[name=og\\:' + name + ']').attr('content');
}

Share = {
    go: function(_element, _options) {
        var
            self = Share,
            options = jQuery.extend({
                    type:       'vk',    // тип соцсети
                    url:        location.href,  // какую ссылку шарим
                    count_url:  location.href,  // для какой ссылки крутим счётчик
                    //title:      document.title, // заголовок шаринга
                    //image:        '',             // картинка шаринга
                    //text:       '',             // текст шаринга
                    title:      get_og_param('title'),        // заголовок шаринга
                    image:      get_og_param('image'),        // картинка шаринга
                    text:       get_og_param('description'),  // текст шаринга
                },
                jQuery(_element).data(), // Если параметры заданы в data, то читаем их
                _options            // Параметры из вызова метода имеют наивысший приоритет
            );

        if (self.popup(link = self[options.type](options)) === null) {
            // Если не удалось открыть попап
            if ( jQuery(_element).is('a') ) {
                // Если это <a>, то подставляем адрес и просим браузер продолжить переход по ссылке
            	jQuery(_element).prop('href', link);
                return true;
            }
            else {
                // Если это не <a>, то пытаемся перейти по адресу
                location.href = link;
                return false;
            }
        }
        else {
            // Попап успешно открыт, просим браузер не продолжать обработку
            return false;
        }
    },
    // ВКонтакте
    vk: function(_options) {
        var options = jQuery.extend({
                url:    location.href,
                title:  document.title,
                image:  '',
                text:   '',
            }, _options);
        return 'http://vkontakte.ru/share.php?'
            + 'url='          + encodeURIComponent(options.url)
            + '&title='       + encodeURIComponent(options.title)
            + '&image='       + encodeURIComponent(options.image)
            + '&description=' + encodeURIComponent(options.text);
    },
    // Одноклассники
    ok: function(_options) {
        var options = jQuery.extend({
                url:    location.href,
                text:   '',
            }, _options);
        return 'https://connect.ok.ru/offer?url='+ encodeURIComponent(options.url)
            + '&title='     + encodeURIComponent(options.title)
            + '&imageUrl='  + encodeURIComponent(options.image);
    },
    // Facebook
    fb: function(_options) {
        var options = jQuery.extend({
                url:    location.href,
                title:  document.title,
                image:  '',
                text:   '',
            }, _options);
        return 'http://www.facebook.com/sharer.php?src=sp'
        	+ '&u='       + encodeURIComponent(options.url)
            + '&title='     + encodeURIComponent(options.title)
            + '&picture=' + encodeURIComponent(options.image);
            //+ '&description='   + encodeURIComponent(options.text)
            
    },
    // Живой Журнал
    lj: function(_options) {
        var options = jQuery.extend({
                url:    location.href,
                title:  document.title,
                text:   '',
            }, _options);
        return 'http://livejournal.com/update.bml?'
            + 'subject='        + encodeURIComponent(options.title)
            + '&event='         + encodeURIComponent(options.text + '<br/><a href="' + options.url + '">' + options.title + '</a>')
            + '&transform=1';
    },
    // Твиттер
    tw: function(_options) {
        var options = jQuery.extend({
                url:        location.href,
                count_url:  location.href,
                title:      document.title,
            }, _options);
        return 'https://twitter.com/intent/tweet?'
            + 'text='      + encodeURIComponent(options.title)
            + '&url='      + encodeURIComponent(options.url);
        	//+ 'text='      + encodeURIComponent(options.title)
        	//+ '&url='      + encodeURIComponent(options.url);

        //+ '&counturl=' + encodeURIComponent(options.count_url);
    },

    // Mail.Ru
    ml: function(_options) {
        var options = jQuery.extend({
                url:    location.href,
                title:  document.title,
                image:  '',
                text:   '',
            }, _options);
        return 'http://connect.mail.ru/share?'
            + 'url='          + encodeURIComponent(options.url)
            + '&title='       + encodeURIComponent(options.title)
            + '&description=' + encodeURIComponent(options.text)
            + '&imageurl='    + encodeURIComponent(options.image);
    },
    //
    li: function(_options) {
        var options = jQuery.extend({
            url:    location.href,
            title:  document.title,
            text:   ''
        }, _options);
        return 'http://www.linkedin.com/shareArticle?mini=true'
            + '&url='       + encodeURIComponent(options.url)
            + '&title='     + encodeURIComponent(options.title)
            + '&summary='   + encodeURIComponent(options.text);
    },
    ln: function(_options) {
        var options = jQuery.extend({
            url:    location.href,
            title:  document.title,
            text:   ''
        }, _options);
        return 'http://www.linkedin.com/shareArticle?mini=true'
            + '&url='       + encodeURIComponent(options.url)
            + '&title='     + encodeURIComponent(options.title);
            //+ '&summary='   + encodeURIComponent(options.text);
    },
    pn: function(_options) {
        var options = jQuery.extend({
            url:    location.href,
            title:  document.title,
            text:   ''
        }, _options);
        return 'http://www.linkedin.com/shareArticle?mini=true'
            + '&url='       + encodeURIComponent(options.url)
            + '&title='     + encodeURIComponent(options.title);
            //+ '&summary='   + encodeURIComponent(options.text);
    },
    bl: function(_options) {
        var options = jQuery.extend({
            url:    location.href,
            title:  document.title,
            text:   ''
        }, _options);
        return 'https://www.blogger.com/blog-this.g'
            + '?u='       + encodeURIComponent(options.url)
            + '&n='     + encodeURIComponent(options.title);
            //+ '&summary='   + encodeURIComponent(options.text);
    },
    wb: function(_options) {
        var options = jQuery.extend({
            url:    location.href,
            title:  document.title,
            text:   ''
        }, _options);
        return 'http://service.weibo.com/share/share.php?type=3'
            + '&url='       + encodeURIComponent(options.url)
            + '&title='     + encodeURIComponent(options.title);
            //+ '&summary='   + encodeURIComponent(options.text);
    },
    // WhatsApp
    wa: function(_options) {
        var options = jQuery.extend({
            url:    location.href,
            title:  document.title,
            text:   ''
        }, _options);
        return 'https://api.whatsapp.com/send'
        	+ '?text='       + encodeURIComponent(options.title)
        	+ '%20%20' + encodeURIComponent(options.url);
    },
    // Telegram
    tl: function(_options) {
        var options = jQuery.extend({
            url:    location.href,
            title:  document.title,
            text:   ''
        }, _options);
        return 'https://telegram.me/share/url?url='+ encodeURIComponent(options.url)
        	+ '?text='       + encodeURIComponent(options.title);
    },
    // Viber
    vi: function(_options) {
        var options = jQuery.extend({
            url:    location.href,
            title:  document.title,
            text:   ''
        }, _options);
        return 'viber://forward?text='+encodeURIComponent(options.title)+encodeURIComponent(options.url);
    },
    // Открыть окно
    popup: function(url) {
    	var ww=626, wh=436;
        var t=(screen.height/2)-(wh/2);
        var l=(screen.width/2)-(ww/2);
    	return window.open(url,'','top='+t+',left='+l+',toolbar=0,status=0,scrollbars=1,width='+ww+',height='+wh);
    }
}
