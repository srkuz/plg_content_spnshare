<?php
/**
 * @version		0.9.x
 * @plugin		spnshare
 * @author		Sergey Kuznetsov http://www.seoprosto.net
 * @copyright		Copyright (c) 2015 SeoProsto.Net. All rights reserved.
 * @license   		http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

defined('_JEXEC') or die;

if(!class_exists('SH')){
//	class SH extends \Joomla\String\StringHelper{}
}
//use Joomla\Registry\Registry;

class PlgContentSPNShare extends JPlugin {
	protected $like=['fb','vk','tw','ok','ml','ln','pn','lj','bl','wb','tl','wa','vi'];

	public function __construct(& $subject, $config) {
		parent::__construct($subject, $config);
	}
	
	public function onContentPrepare($context, &$article, &$params, $page = 0){
		$app = JFactory::getApplication();
		if ($app->isClient('administrator')){
			return true;
		}
		if(strpos($context, 'mod_custom')===false){ // Обрабатываем только модуль mod_custom
			return true;
		}
		if(strlen(trim($article->text))>0){ // Обрабатываем если модуль mod_custom пустой			
			return true;
		}
		$doc = JFactory::getDocument();
		//$doc->addStyleSheet(JURI::root(true) . '/plugins/content/spnshare/css/spnshare.css', array('version' => 'auto'));
		
		$plugin  = JPluginHelper::getPlugin('content','spnshare');
		$pluginP = new JRegistry();
		$pluginP->loadString($plugin->params);
		
		$cnt=0;
		$al=array();
		$cntshare=array();
		foreach($this->like as $l){
			$cl=(int)$pluginP->get($l, 0);
			if($cl!=0){
				++$cnt;
				$pl=(int)$pluginP->get($l.'_order',1);
				$al[]=[$pl,$l,$cl]; //  Порядок (1),СоцСеть(fb), признак использования (0/1)
				if((int)$pluginP->get($l.'_cnt',0)>0){
					$cntshare[$l]=1;
				}
			}
		}
		if($cnt == 0){ // не задано ни одной сс
			return true;
		}
		$cntjs=json_encode($cntshare);
		usort($al,'pos_sort');
		// div to bode
		$html='<div id="ss-share" class="ss" >';
		foreach($al as $l){
			$html.='<a class="ss-btn ss-'.$l[1].' ico-'.$l[1].' ico" data-type="'.$l[1].'"><i class="ico-'.$l[1].'"></i></a>';
		}
		$html.='</div>';
		// JS
		$jsf=JURI::root(true).'/plugins/content/spnshare/js/spnshare.js';
		$jsi='<script async src="'.$jsf.'"></script></body>';
		
		// Add style to header
		$sw=(int)$pluginP->get('sitewidth',1260);
		$lefttop=(int)$pluginP->get('lefttop',100);
		$mini=(int)$pluginP->get('minify',1);
		$min=($mini==1?'.min':'');
		$css='';
		$file=JPATH_ROOT.'/plugins/content/spnshare/css/spnshare.css';
		if(JFile::exists($file)){
			$css = file_get_contents($file);
		}
		$cssm ='';
		$cssm.='@media (min-width: '.$sw.'px){
				#ss-share{
					top:'.$lefttop.'px!important;
					bottom:auto;
				}
				.ss .ico{
					width:40px;
    				height:40px;
    				transition: width .15s ease-in-out;
				}
				.ss .ico:hover{
					width:55px;
				}'
				.(isset($cntshare['vk'])?' .ss .ico-vk {height:50px;} .ss .ico-vk i{padding-top:35px;}':' ')
				.(isset($cntshare['fb'])?' .ss .ico-fb {height:50px;} .ss .ico-fb i{padding-top:35px;}':' ')
				.(isset($cntshare['ok'])?' .ss .ico-ok {height:50px;} .ss .ico-ok i{padding-top:35px;}':' ')
				.'.ss .ico{background-size:40px;}
			}';
		$cssm.='@media (max-width:'.($sw-1).'px){
				#ss-share {
					top:auto;
					left:0;
					right:0;
					bottom:0;
					width:100%;
					max-width:100%;
					box-shadow: 0 0 1px 1px #e2dfe2;
				}
				.ss a{
					float:left;
				}
				.ss .ico {
					width:'.round(100/$cnt,3,PHP_ROUND_HALF_DOWN).'%;
    				height:25px;
				}
				.ss .ico:hover{
					opacity:0.85;
				}
			}';
		$cssa=preg_replace("/\s{2,}/",' ',$cssm.$css);
		//$doc->addStyleDeclaration(preg_replace("/\s{2,}/",' ',$cssa));
		
		$file=JPATH_ROOT.'/plugins/content/spnshare/js/spnshare'.$min.'.js';
		if(JFile::exists($file)){
			$jsc = file_get_contents($file);
			$doc->addScriptDeclaration($jsc);
		}
		$jshtml="
			jQuery(document).ready(function() {
				jQuery(function($){
					jQuery('head').append('<style type=\"text/css\">".addslashes($cssa)."</style>');
					jQuery('body').append('".$html."');
					jQuery(document).on('click', '.ss-btn', function(){Share.go(this);});
					CntView(".$sw.",".$cntjs.");
				});
			});
		";
		$doc->addScriptDeclaration(preg_replace("/\s{2,}/",' ',$jshtml));
	}
}
//
function pos_sort($x, $y){
	if ($x[0] > $y[0]){
		return true;
	} else if ($x[0] < $y[0]){
		return false;
	} else {
		return 0;
	}
}
